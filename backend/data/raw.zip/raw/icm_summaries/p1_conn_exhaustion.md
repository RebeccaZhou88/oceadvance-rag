# IcM 事件摘要：P1 订单服务连接池耗尽

## 事件元信息
- 事件 ID：INC-2026-0310-001（合成示例）
- 严重级别：P1
- 触发时间：2026-03-10 14:00 UTC
- 当前状态：Resolved

## 处置流程
1. **Ack（5 分钟内）**：值班 SRE 在 IcM 中 ack，自动拉通 on-call 与值班指挥。
2. **Mitigated**：14:10 扩容连接池、重启实例后错误率回落。
3. **Resolved**：14:23 确认无复发，标记 resolved。

## 关键 Kusto
```
let incident = "INC-2026-0310-001";
OrdersApiLogs
| where TimeGenerated between (datetime(2026-03-10 14:00) .. datetime(2026-03-10 14:30))
| summarize err5xx = countif(statusCode >= 500), total = count() by bin(TimeGenerated, 1m)
| project TimeGenerated, err5xx, errRatio = round(err5xx*1.0/total,3)
```

## 经验
P1 事件须在 5 分钟内 ack，值班指挥负责拉通 on-call；缓解（mitigated）后仍需观察 15 分钟方可 resolved。

> 合成数据，仅用于原型演示。
