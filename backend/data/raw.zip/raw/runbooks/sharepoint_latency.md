# SharePoint 高延迟排查 Runbook

## 排查目标
当 SharePoint Online/OnPrem 用户反馈页面加载超过 3 秒或上传卡顿时，按本手册逐步定位。

## H2 第一步：检查应用网关
- 登录 Azure Portal，进入应用网关（Application Gateway）资源页。
- 查看「后端健康」面板，确认后端池成员健康状态均为 Healthy。
- 查看「指标」面板，关注 `failedReqRatio`（失败请求比例），阈值应 < 2%。

## H3 Kusto 查询模板
```
AppGwLogs
| where TimeGenerated > ago(30m)
| summarize total = count(), failed = countif(httpResponseStatus_d >= 500)
    by backend, bin(TimeGenerated, 5m)
| project backend, bin_TimeGenerated = TimeGenerated,
    failedReqRatio = round(failed * 1.0 / total, 3)
| order by failedReqRatio desc
```

## H2 第二步：排查后端数据库
- 若应用网关正常，进入 SharePoint 后端 SQL Server。
- 检查 `sys.dm_tran_locks` 是否存在大量阻塞锁。
- 检查连接池是否耗尽（`sys.dm_exec_connections` 数量接近 `max_workers`）。

## H3 缓解措施
1. 临时扩容：将应用服务计划横向扩展 2 个实例。
2. 重启受影响实例以释放连接池。
3. 通知值班 SRE 跟进长事务代码路径。

## 告警阈值
- P95 延迟 > 5s 触发 P2 告警。
- failedReqRatio > 5% 触发 P1 告警。
